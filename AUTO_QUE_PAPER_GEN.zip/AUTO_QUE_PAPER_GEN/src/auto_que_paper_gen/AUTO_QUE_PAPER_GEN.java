
package auto_que_paper_gen;

import java.awt.Dimension;
import java.awt.Toolkit;

public class AUTO_QUE_PAPER_GEN {

  
    public static void main(String[] args)
    {
        LOGIN_FRAME lf=new LOGIN_FRAME();
        Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
        lf.setVisible(true);
        lf.setSize(d);
        
        
    }
    
}

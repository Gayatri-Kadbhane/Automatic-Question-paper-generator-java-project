/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author gayat
 */
public class Serial_number_fetcher 
{
    public ArrayList getSr_no(Statement st)
    { 
        ArrayList sr_no=new ArrayList();
        try
        {
//            Class.forName("com.mysql.jdbc.Driver").newInstance();
//               Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/auto_ques_gen", "root","root");
//               Statement st=con.createStatement();
               
               String query="select * from question_set";
               ResultSet rs=st.executeQuery(query);
               while(rs.next())
               {
                   sr_no.add(rs.getString(1));
               }
               System.out.println("Sr_no:="+sr_no);

        }
        catch(Exception ex)
        {
            System.out.println("Exception is :"+ex);
        }
        return sr_no;
    }      
   
    
}

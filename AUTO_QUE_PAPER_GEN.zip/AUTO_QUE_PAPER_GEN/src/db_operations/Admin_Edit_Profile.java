/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author gayat
 */
public class Admin_Edit_Profile 
{
    public boolean isUpadated(String name,String mobile,String email,String register_as,String username,String password )
    {
        boolean flag=false;
        try
        {
//            Class.forName("com.mysql.jdbc.Driver").newInstance();
//           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/auto_ques_gen", "root","root");
//           Statement st=con.createStatement();
           
            Statement st=new DB_Driver().getStatement();
            
           //String query="update registration_info set name='"+name+"',mobile_number='"+mobile+"',email_id='"+email+"',register_as='"+register_as+"',username='"+username+"',password='"+password+"' where username='"+username+"'";
              
           String query="update registration_info set name='"+name+"',mobile_number='"+mobile+"',email_id='"+email+"',register_as='"+register_as+"',password='"+password+"' where username='"+username+"'";
            
            
            
           int x=st.executeUpdate(query);
           
           if(x>0)
               flag=true;
           else
               flag=false;

        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
            
        }
        return flag;
        
    }
    
}

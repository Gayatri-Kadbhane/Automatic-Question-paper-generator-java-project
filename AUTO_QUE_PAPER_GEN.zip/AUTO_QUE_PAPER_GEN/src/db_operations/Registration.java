/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.Connection;
import java.sql.*;

/**
 *
 * @author gayat
 */
public class Registration
{
    public boolean isRegister(String name,String mobile,String email,String register_as,String username,String password)
    {
        boolean flag=false;
        
        try
        {
//           Class.forName("com.mysql.jdbc.Driver").newInstance();
//           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/auto_ques_gen", "root","root");
//           Statement st=con.createStatement();
            Statement st=new DB_Driver().getStatement();
           
           String query="insert into registration_info values('"+name+"','"+mobile+"','"+email+"','"+register_as+"','"+username+"','"+password+"')";
           int x=st.executeUpdate(query);
           if(x>0)
               flag=true;
           else
               flag=false;
        }
        catch(Exception ex)
        {
            System.out.print("Exception is:"+ex);
            
        }
        return flag;
    }
    
}

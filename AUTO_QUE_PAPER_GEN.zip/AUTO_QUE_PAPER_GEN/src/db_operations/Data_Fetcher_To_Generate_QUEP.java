/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gayat
 */
public class Data_Fetcher_To_Generate_QUEP 
{
    public String getTeacher_Name(Statement st,String username)
    {
        String teacher_name=" ";
        try
        {
            String query="select * from registration_info where username ='"+username+"'";
            ResultSet rs=st.executeQuery(query);
            if(rs.next())
            {
                teacher_name=rs.getString(1);
               
            }
            System.out.println("Teacher Name="+teacher_name);
        }
        
        catch(Exception ex)
        {
                    System.out.println("Exception is="+ex);
                    
        }
        
        return teacher_name;
    }
   
    public ArrayList getDepartment(Statement st,String teachername)
    {
        ArrayList dept=new ArrayList();
        try
        {
            String query="select * from question_set where teacher_name='"+teachername+"'";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                dept.add(rs.getString(2));
                
            }
            System.out.println("Department list is:"+dept);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return dept;
    }
    
     public ArrayList getSemester(Statement st,String teachername)
    {
        ArrayList sem=new ArrayList();
        try
        {
            String query="select * from question_set where teacher_name='"+teachername+"'";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                sem.add(rs.getString(3));
                
            }
            System.out.println("semester list is:"+sem);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return sem;
    }
     
      public ArrayList getSubject(Statement st,String teachername)
    {
        ArrayList sub=new ArrayList();
        try
        {
            String query="select * from question_set where teacher_name='"+teachername+"'";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                sub.add(rs.getString(4));
                
            }
            System.out.println("subject list is:"+sub);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return sub;
    }
     
           
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author gayat
 */
public class Admin_Login 
{
    public boolean isLogin(String username,String password,String you)
    {
        boolean flag=false;
        try
        {
//            Class.forName("com.mysql.jdbc.Driver").newInstance();
//           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/auto_ques_gen", "root","root");
//           Statement st=con.createStatement();
//           
            Statement st=new DB_Driver().getStatement();
            
           String query="Select * from registration_info where username='"+username+"'and password='"+password+"' and register_as='"+you+"'";
           
           ResultSet rs=st.executeQuery(query);
           if(rs.next())
               flag=true;
           else
               flag=false;
        }
        catch(Exception ex)
        {
            System.out.print("Exception is:"+ex);
            
        }
        return flag;
    }
    
}

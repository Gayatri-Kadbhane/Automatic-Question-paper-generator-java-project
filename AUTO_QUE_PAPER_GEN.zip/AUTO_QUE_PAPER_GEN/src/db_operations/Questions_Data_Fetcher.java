/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author gayat
 */
public class Questions_Data_Fetcher 
{
    public ArrayList getDepartment(Statement st)
    {
        ArrayList dept=new ArrayList();
        try
        {
            String query="select * from question_set";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                dept.add(rs.getString(2));
                
            }
            System.out.println("Department list is:"+dept);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return dept;
    }
    
     public ArrayList getSemester(Statement st)
    {
        ArrayList sem=new ArrayList();
        try
        {
            String query="select * from question_set";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                sem.add(rs.getString(3));
                
            }
            System.out.println("semester list is:"+sem);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return sem;
    }
     
      public ArrayList getSubject(Statement st)
    {
        ArrayList sub=new ArrayList();
        try
        {
            String query="select * from question_set";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                sub.add(rs.getString(4));
                
            }
            System.out.println("subject list is:"+sub);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return sub;
    }
     public ArrayList getTeacher_Name(Statement st)
    {
        ArrayList teacher_name=new ArrayList();
        try
        {
            String query="select * from question_set";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                teacher_name.add(rs.getString(9));
                
            }
            System.out.println("teacher_name list is:"+teacher_name);
        }
        catch(Exception ex)
        {
            System.out.println("Excepton is:"+ex);
            
        }
        return teacher_name;
    }
    
           
}

   
            


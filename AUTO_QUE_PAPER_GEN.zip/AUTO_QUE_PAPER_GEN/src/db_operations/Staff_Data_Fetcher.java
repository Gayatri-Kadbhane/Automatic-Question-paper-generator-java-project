/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author gayat
 */
public class Staff_Data_Fetcher 
{
     public ArrayList getData(String username)
    {
        ArrayList data=new ArrayList();
        try
        {
//            Class.forName("com.mysql.jdbc.Driver").newInstance();
//           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/auto_ques_gen", "root","root");
//           Statement st=con.createStatement();
           
            Statement st=new DB_Driver().getStatement();
            
           String query="select* from registration_info where username='"+username+"'";
           ResultSet rs=st.executeQuery(query);
           if(rs.next())
           {
               data.add(rs.getString(1));
               data.add(rs.getString(2));
               data.add(rs.getString(3));
               data.add(rs.getString(4));
               data.add(rs.getString(5));
               data.add(rs.getString(6));
           }
          
        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
        }
        return data;
        
    }
   
    
}

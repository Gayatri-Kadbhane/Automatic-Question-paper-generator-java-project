/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author gayat
 */
public class Upload_question
{
    public boolean isquestion_Uploaded(Statement st,String sr_no,String dept,String sem,String sub,String unit,String que,String level,String marks,String teacher_name)
    {
        boolean flag=false;
       try
        {
//           Class.forName("com.mysql.jdbc.Driver").newInstance();
//           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/auto_ques_gen", "root","root");
//           Statement st=con.createStatement();
//           
              
              
           String query="insert into question_set values('"+sr_no+"','"+dept+"','"+sem+"','"+sub+"','"+unit+"','"+que+"','"+level+"','"+marks+"','"+teacher_name+"')";
           int x=st.executeUpdate(query);
           if(x>0)
               flag=true;
           else
               flag=false;
           
        }
        catch(Exception ex)
        {
            System.out.print("Exception is:"+ex);
            
        }
        return flag;
    }
    
}
